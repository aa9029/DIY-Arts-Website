// Import required modules
const express = require('express');
const mysql = require('mysql');

// Create an Express application
const app = express();

// Database configuration
const db = mysql.createConnection({
    host: 'localhost',
    user: 'username',
    password: 'password',
    database: 'loginpage'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL database:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

